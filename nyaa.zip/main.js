import AbstractSource from './abstract.js'

export default new class Nyaa extends AbstractSource {
  url = 'https://nyaa.si'

  async single({ titles }) {
    if (!titles || titles.length === 0) throw new Error('No titles provided')
    const query = encodeURIComponent(titles[0])
    const res = await fetch(this.url + '/?f=0&c=1_2&q=' + query)
    const html = await res.text()

    const results = []
    const regex = /<a href="\/view\/(\d+)" title="([^"]+)"/g
    let match
    while ((match = regex.exec(html)) !== null) {
      results.push({
        title: match[2],
        link: 'https://nyaa.si/view/' + match[1],
        hash: match[1],
        size: 0,
        type: 'alt',
        date: new Date(),
        seeders: 0,
        leechers: 0,
        downloads: 0,
        accuracy: 'medium'
      })
    }
    return results
  }

  batch = this.single
  movie = this.single

  async test() {
    const res = await fetch(this.url)
    return res.ok
  }
}()
