import AbstractSource from './abstract.js'

export default new class TokyoTosho extends AbstractSource {
  url = 'https://www.tokyotosho.info'

  async single ({ titles }) {
    if (!titles?.length) throw new Error('No titles provided')
    const query = encodeURIComponent(titles[0])
    const res = await fetch(`${this.url}/search.php?terms=${query}`)
    const html = await res.text()

    const results = []
    const regex = /<a href="magnet:\?xt=urn:btih:([^"]+)"[^>]*>([^<]+)<\/a>/g
    let match

    while ((match = regex.exec(html)) !== null) {
      results.push({
        title: match[2],
        link: `magnet:?xt=urn:btih:${match[1]}`,
        hash: match[1],
        size: 0,
        type: 'alt',
        date: new Date(),
        seeders: 0,
        leechers: 0,
        downloads: 0,
        accuracy: 'medium'
      })
    }

    return results
  }

  batch = this.single
  movie = this.single

  async test () {
    const res = await fetch(this.url)
    return res.ok
  }
}()
